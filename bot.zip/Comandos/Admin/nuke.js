const { ApplicationCommandType } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: `nuke`,
    description: `🔗 Recria canal(exclui todas as mensagem do canal).`,
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== config.owner) {
            return interaction.reply({
                content: `❌ Você não tem permissão para usar este comando.`,
                ephemeral: true
            });
        }

        const newChannel = await interaction.channel.clone();

        await interaction.channel.delete();

        newChannel.send({
            content: `Nuked by \`${interaction.user.username}\``
        });
    }
};
